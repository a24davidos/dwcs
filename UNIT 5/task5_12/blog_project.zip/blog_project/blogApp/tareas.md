1. Tengo que añadir el image upload, y eliminar el image_name para poder subir la imagenes, pero ten cuidad o de no romper la base de datos
